
import json
import pandas as pd
from simple_salesforce import Salesforce
import snowflake.connector
from config import settings
from data_dict import SF_OBJECT_TO_SNOWFLAKE_TABLE
from utils import print_record_fields
from jwt import encode as jwt_encode
from cryptography.hazmat.primitives import serialization
import time
import requests

# Load private key
def load_private_key(file_path):
    with open(file_path, 'rb') as key_file:
        return serialization.load_pem_private_key(key_file.read(), password=None)

# Create JWT assertion
def create_jwt_assertion(client_id, username, login_url, private_key):
    issued_at = int(time.time())
    expiration = issued_at + 300
    payload = {
        'iss': client_id,
        'sub': username,
        'aud': str(login_url),
        'exp': expiration,
        'iat': issued_at
    }
    return jwt_encode(payload, private_key, algorithm='RS256')

# Get Salesforce access token
def get_salesforce_access_token(jwt_token, login_url):
    token_url = f'{login_url}/services/oauth2/token'
    response = requests.post(token_url, data={
        'grant_type': 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion': jwt_token
    })
    print("Salesforce token response:", response.text)
    return response.json()

# Connect to Salesforce
def connect_salesforce():
    private_key = load_private_key(settings.SF_PRIVATE_KEY_FILE)
    jwt_token = create_jwt_assertion(settings.SF_CLIENT_ID, settings.SF_USERNAME, settings.SF_LOGIN_URL, private_key)
    response_data = get_salesforce_access_token(jwt_token, settings.SF_LOGIN_URL)
    if 'access_token' not in response_data:
        raise Exception("Failed to retrieve Salesforce access token")
    return Salesforce(instance_url=response_data['instance_url'], session_id=response_data['access_token'])

# Connect to Snowflake
def connect_snowflake():
    return snowflake.connector.connect(
        account="NP91221-IC_IBD_CRM",
        user="rajani.gutha@blueowl.com",
        authenticator='externalbrowser',
        role="IC_CRM_DEVELOPER",
        warehouse='"IC_CRM_WH_XS"',
        database='IC_CRM_DB',
        schema='IC_CRM'
    )

# Validation functions
def validate_row_count(sf, cur, sf_object, snowflake_table):
    sf_count = sf.query(f"SELECT COUNT(Id) FROM {sf_object}")['records'][0].get('expr0', 0)
    cur.execute(f"SELECT COUNT(*) FROM {snowflake_table}")
    snowflake_count = cur.fetchone()[0]
    return sf_count, snowflake_count

def validate_column_count(sf, cur, sf_object, snowflake_table):
    sf_fields = getattr(sf, sf_object).describe()['fields']
    sf_field_names = [f['name'] for f in sf_fields]
    cur.execute(f"SELECT * FROM {snowflake_table} LIMIT 1")
    snowflake_field_names = [desc[0] for desc in cur.description]
    return len(sf_field_names), len(snowflake_field_names)

def validate_row_level_data(sf, cur, sf_object, snowflake_table):
    sf_fields = getattr(sf, sf_object).describe()['fields']
    field_names = [f['name'] for f in sf_fields]
    sf_data = sf.query(f"SELECT {', '.join(field_names)} FROM {sf_object} LIMIT 10")['records']
    cur.execute(f"SELECT * FROM {snowflake_table} LIMIT 10")
    snowflake_data = cur.fetchall()
    snowflake_columns = [desc[0] for desc in cur.description]
    mismatches = []
    for i, sf_record in enumerate(sf_data):
        if i >= len(snowflake_data):
            mismatches.append(f"Missing Snowflake record for Salesforce record {i}")
            continue
        for field in field_names:
            sf_value = sf_record.get(field)
            if field in snowflake_columns:
                snowflake_value = snowflake_data[i][snowflake_columns.index(field)]
                if sf_value != snowflake_value:
                    mismatches.append(f"Mismatch in record {i}, field '{field}': SF='{sf_value}' vs SFK='{snowflake_value}'")
    return mismatches

def validate_column_level_data(cur, snowflake_table):
    cur.execute(f"SELECT * FROM {snowflake_table} LIMIT 100")
    df = pd.DataFrame(cur.fetchall(), columns=[desc[0] for desc in cur.description])
    null_counts = df.isnull().sum().to_dict()
    duplicate_counts = df.duplicated().sum()
    dtypes = df.dtypes.apply(lambda x: str(x)).to_dict()
    return dtypes, null_counts, duplicate_counts

# Main function
def run_validations():
    sf = connect_salesforce()
    conn = connect_snowflake()
    cur = conn.cursor()
    report = []
    for mapping in SF_OBJECT_TO_SNOWFLAKE_TABLE:
        sf_object = mapping['sf_object']
        snowflake_table = mapping['snowflake_table']
        row_sf, row_sfk = validate_row_count(sf, cur, sf_object, snowflake_table)
        col_sf, col_sfk = validate_column_count(sf, cur, sf_object, snowflake_table)
        row_mismatches = validate_row_level_data(sf, cur, sf_object, snowflake_table)
        dtypes, nulls, duplicates = validate_column_level_data(cur, snowflake_table)
        report.append({
            'Object': sf_object,
            'Table': snowflake_table,
            'RowCount_SF': row_sf,
            'RowCount_SFK': row_sfk,
            'ColumnCount_SF': col_sf,
            'ColumnCount_SFK': col_sfk,
            'RowLevelMismatches': row_mismatches,
            'ColumnDataTypes': dtypes,
            'NullCounts': nulls,
            'DuplicateCount': duplicates
        })
    cur.close()
    conn.close()
    df_report = pd.DataFrame(report)
    df_report.to_excel("validation_report.xlsx", index=False)
    df_report.to_html("validation_report.html", index=False)
    print("✅ Validation reports generated: validation_report.xlsx, validation_report.html")

if __name__ == '__main__':
    run_validations()
