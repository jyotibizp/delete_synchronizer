
# utils.py

def print_record_fields(record):
    for key, value in record.items():
        print(f"{key}: {value}")
