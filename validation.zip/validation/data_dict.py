
# data_dict.py

SF_OBJECT_TO_SNOWFLAKE_TABLE = [
    {
        "sf_object": "Account",
        "snowflake_table": "ACCOUNT"
    },
    {
        "sf_object": "Contact",
        "snowflake_table": "CONTACT"
    },
    {
        "sf_object": "Opportunity",
        "snowflake_table": "OPPORTUNITY"
    },
       {"sf_object": "Legal_Entity__c", "snowflake_table": "LegalEntity"},
    {"sf_object": "Investment__c", "snowflake_table": "Investment"},
    {"sf_object": "LP_Consultant_Relationship__c", "snowflake_table": "LPConRelationship"},
    {"sf_object": "Event", "snowflake_table": "Event"},
    {"sf_object": "Task", "snowflake_table": "Task"},
    {"sf_object": "Activity_Content__c", "snowflake_table": "ActivityContent"},
    {"sf_object": "Fund__c", "snowflake_table": "Fund"},

    
]
# Add more mappings as needed