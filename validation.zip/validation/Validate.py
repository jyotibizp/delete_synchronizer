import json
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill
from openpyxl.worksheet.table import Table, TableStyleInfo
from jinja2 import Template
import os

# Define paths
sf_path = 'data/salesforce_output.json'
sn_path = 'data/snowflake_output.json'
excel_output = 'validation/validation_results.xlsx'
html_output = 'validation/validation_report.html'

# Create folders if they don't exist
os.makedirs('data', exist_ok=True)
os.makedirs('validation', exist_ok=True)

# Load JSON data
with open(sf_path) as sf_file:
    sf_data = json.load(sf_file)

with open(sn_path) as sn_file:
    sn_data = json.load(sn_file)

# Flatten the data into dictionaries
sf_counts = {list(d.keys())[0]: list(d.values())[0] for d in sf_data}
sn_counts = {list(d.keys())[0]: list(d.values())[0][0] for d in sn_data}  # Snowflake returns tuple

# Create a DataFrame for comparison
comparison = pd.DataFrame([{
    'Object/Table': key,
    'Salesforce Count': sf_counts.get(key, 'Missing'),
    'Snowflake Count': sn_counts.get(key, 'Missing'),
    'Match': sf_counts.get(key) == sn_counts.get(key)
} for key in set(sf_counts) | set(sn_counts)])

# Save to Excel with formatting
wb = Workbook()
ws = wb.active
ws.title = "Validation Results"

# Write headers
headers = list(comparison.columns)
ws.append(headers)

# Write data rows
for _, row in comparison.iterrows():
    ws.append(list(row))

# Apply table style
tab = Table(displayName="ValidationTable", ref=f"A1:D{len(comparison)+1}")
table_style = TableStyleInfo(name="TableStyleMedium9", showRowStripes=True)
tab.tableStyleInfo = table_style
ws.add_table(tab)

# Highlight mismatches
for row in ws.iter_rows(min_row=2, max_row=len(comparison)+1, min_col=4, max_col=4):
    for cell in row:
        if cell.value is False:
            cell.fill = PatternFill(start_color="FF9999", end_color="FF9999", fill_type="solid")

wb.save(excel_output)

# Generate HTML report
html_template = Template("""
<html>
<head><title>Validation Report</title></head>
<body>
<h2>Salesforce vs Snowflake Validation</h2>
<table border="1" cellpadding="5" cellspacing="0">
<tr><th>Object/Table</th><th>Salesforce Count</th><th>Snowflake Count</th><th>Match</th></tr>
{% for row in data %}
<tr style="background-color: {% if not row['Match'] %}#FFCCCC{% else %}#CCFFCC{% endif %};">
<td>{{ row['Object/Table'] }}</td>
<td>{{ row['Salesforce Count'] }}</td>
<td>{{ row['Snowflake Count'] }}</td>
<td>{{ row['Match'] }}</td>
</tr>
{% endfor %}
</table>
</body>
</html>
""")

html_content = html_template.render(data=comparison.to_dict(orient='records'))
with open(html_output, "w") as f:
    f.write(html_content)

print("✅ Validation completed. Excel and HTML reports generated.")