import pandas as pd
import snowflake.connector
from simple_salesforce import Salesforce
from config import settings
from cryptography.hazmat.primitives import serialization
from jwt import encode as jwt_encode
import time
import requests

# Load private key
def load_private_key(file_path):
    with open(file_path, 'rb') as key_file:
        return serialization.load_pem_private_key(key_file.read(), password=None)

# Create JWT assertion
def create_jwt_assertion(client_id, username, login_url, private_key):
    issued_at = int(time.time())
    expiration = issued_at + 300
    payload = {
        'iss': client_id,
        'sub': username,
        'aud': str(login_url),
        'exp': expiration,
        'iat': issued_at
    }
    return jwt_encode(payload, private_key, algorithm='RS256')

# Get Salesforce access token
def get_salesforce_access_token(jwt_token, login_url):
    token_url = f'{login_url}/services/oauth2/token'
    response = requests.post(token_url, data={
        'grant_type': 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion': jwt_token
    })
    return response.json()

# Connect to Salesforce
def connect_salesforce():
    private_key = load_private_key(settings.SF_PRIVATE_KEY_FILE)
    jwt_token = create_jwt_assertion(settings.SF_CLIENT_ID, settings.SF_USERNAME, settings.SF_LOGIN_URL, private_key)
    response_data = get_salesforce_access_token(jwt_token, settings.SF_LOGIN_URL)
    if 'access_token' not in response_data:
        raise Exception("Failed to retrieve Salesforce access token")
    return Salesforce(instance_url=response_data['instance_url'], session_id=response_data['access_token'])

# Connect to Snowflake
def connect_snowflake():
    return snowflake.connector.connect(
        account="NP91221-IC_IBD_CRM",
        user="rajani.gutha@blueowl.com",
        authenticator='externalbrowser',
        role="IC_CRM_DEVELOPER",
        warehouse="IC_CRM_WH_XS",
        database="IC_CRM_DB",
        schema="IC_CRM"
    )

# Compare two records field by field
def compare_records(df1, df2, key_column):
    merged = df1.merge(df2, on=key_column, suffixes=('_history', '_final'), how='outer', indicator=True)
    diffs = []

    for _, row in merged.iterrows():
        if row['_merge'] != 'both':
            diffs.append(row)
        else:
            for col in df1.columns:
                if col != key_column and row[f"{col}_history"] != row[f"{col}_final"]:
                    diffs.append(row)
                    break
    return pd.DataFrame(diffs)

# Run validations and comparisons
def run_pipeline_testing():
    sf = connect_salesforce()
    conn = connect_snowflake()
    cur = conn.cursor()

    writer = pd.ExcelWriter("pipeline_testing_evidence1.xlsx", engine="openpyxl")

    # Salesforce query
    sf_query = "SELECT count(Id) FROM Account WHERE LastModifiedDate >= 2025-09-23T13:10:38.000Z and RecordTypeId IN ('0123t000000BZLRAA4','0123t000000BZPEAA4','0123t000000JdWRAA0')"
    sf_count = sf.query(sf_query)['records'][0].get('expr0', 0)
    pd.DataFrame([{"Salesforce Account Count (>= 2025-09-30)": sf_count}]).to_excel(writer, sheet_name="Salesforce_Count", index=False)

    # Snowflake queries
    queries = {"SALESFORCE_DELTA_ACCOUNT":"select * from SALESFORCE_DELTA_ACCOUNT",
        "HISTORY_ACCOUNT_FINAL": "SELECT * FROM HISTORY_ACCOUNT_FINAL WHERE EFFECTIVE_TO >= '2025-09-30'",
        "ACCOUNT_FINAL": "SELECT * FROM ACCOUNT_FINAL WHERE EFFECTIVE_FROM >= '2025-09-30'"
    }
    

    dataframes = {}
    for name, query in queries.items():
        cur.execute(query)
        df = pd.DataFrame(cur.fetchall(), columns=[desc[0] for desc in cur.description])
        df.to_excel(writer, sheet_name=name[:31], index=False)
        dataframes[name] = df
    # cur.execute("SELECT * FROM SALESFORCE_DELTA_ACCOUNT")
    # df = pd.DataFrame(cur.fetchall(), columns=[desc[0] for desc in cur.description])
    # df.to_excel(writer, sheet_name='Test', index=False)
    # Compare specific ACCOUNT_IDs
    #account_ids = ['0013t00002diCdAAAU', '0013t00002diCjjAAE']
    #df_history_filtered = dataframes["HISTORY_ACCOUNT_FINAL"][dataframes["HISTORY_ACCOUNT_FINAL"]["ACCOUNT_ID"].isin(account_ids)]
    #df_final_filtered = dataframes["ACCOUNT_FINAL"][dataframes["ACCOUNT_FINAL"]["ACCOUNT_ID"].isin(account_ids)]
    df_history_filtered = dataframes["HISTORY_ACCOUNT_FINAL"]
    df_final_filtered = dataframes["ACCOUNT_FINAL"]
    comparison_df = compare_records(df_history_filtered, df_final_filtered, "ACCOUNT_ID")
    comparison_df.to_excel(writer, sheet_name="Field_Level_Comparison", index=False)

    writer.close()
    cur.close()
    conn.close()
    print("✅ Pipeline testing evidence saved to pipeline_testing_evidence1.xlsx")

if __name__ == "__main__":
    run_pipeline_testing()
