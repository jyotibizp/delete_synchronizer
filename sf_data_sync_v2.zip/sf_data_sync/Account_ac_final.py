import snowflake.connector
import pandas as pd
from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import PatternFill

# Column mappings between Account and Account_final
column_mappings = {
    "account_pod__c": "accountpod",
    "strategic_account__c": "strategicaccount",
    "account_record_type_name__c": "accountrecordtypename",
    "exectutive_account_manager_full_name__c": "exectutiveaccountmanagerfullname",
    "meetings_last_6_months__c": "meetingslast6months",
    "blue_owl_active_investments__c": "blueowlactiveinvestments",
    "first_investment_date__c": "firstinvestmentdate",
    "investor_type__c": "investortype",
    "active_gpsc_investment_mm__c": "activegpscinvestmentmm",
    "first_re_investment_date__c": "firstreinvestmentdate",
    "consultant_investor_type__c": "consultantinvestortype",
    "first_direct_lending_investment_date__c": "firstdirectlendinginvestmentdate",
    "strategy_ies_invested__c": "strategyiesinvested",
    "last_activity_gp_strategic_capital__c": "lastactivitygpstrategiccapital",
    "activeinvest_direct_lending__c": "activeinvestdirectlending",
    "activeinvest_gpsolutions__c": "activeinvestgpsolutions",
    "activeinvest_realestate__c": "activeinvestrealestate",
    "billingcity": "billingcity",
    "billingcountry": "billingcountry",
    "billingstate": "billingstate",
    "client_service_1_full_name__c": "clientservice1",
    "client_service_2_full_name__c": "clientservice2",
    "coverage_region__c": "coverageregion",
    "effective_from": "effective_from",
    "execution_date": "execution_date",
    "first_closed_won_opp__c": "firstclosedwonopp",
    "hash_data": "hash_data",
    "hq_country__c": "hqcountry",
    "id": "accountid",
    "lastactivitydate": "lastactivitydate",
    "lastmodifieddate": "lastmodifieddate",
    "name": "accountname",
    "open_opps__c": "openopportunities",
    "primary_contact__c": "primarycontact",
    "recordtypeid": "recordtypeid",
    "region__c": "geographicregion",
    "sales_person_1__c": "salesperson1",
    "sales_person_2__c": "salesperson2",
    "x18_digit_id__c": "x18_digit_id"
}

def connect_snowflake():
    return snowflake.connector.connect(
        account="NP91221-IC_IBD_CRM",
        user="rajani.gutha@blueowl.com",
        authenticator='externalbrowser',
        role="IC_CRM_DEVELOPER",
        warehouse='"IC_CRM_WH_XS"',
        database='IC_CRM_DB',
        schema='IC_CRM'
    )

def fetch_table(cursor, table_name):
    cursor.execute(f"SELECT * FROM {table_name}")
    cols = [c[0].lower() for c in cursor.description]
    rows = cursor.fetchall()
    return pd.DataFrame(rows, columns=cols)

def compare_by_primary_key(account_df, account_final_df, mappings):
    merged = account_df.merge(account_final_df, left_on='id', right_on='accountid', suffixes=('_src', '_tgt'))
    mismatches = []
    for idx, row in merged.iterrows():
        for src_col, tgt_col in mappings.items():
            if src_col in merged.columns and tgt_col in merged.columns:
                val1 = row[src_col]
                val2 = row[tgt_col]
                if pd.isnull(val1) and pd.isnull(val2):
                    continue
                if val1 != val2:
                    mismatches.append({
                        "id": row['id'],
                        "source_column": src_col,
                        "target_column": tgt_col,
                        "account_value": val1,
                        "account_final_value": val2
                    })
    return pd.DataFrame(mismatches), merged

def generate_excel(counts_df, mismatches_df, merged_df, account_df, account_final_df):
    wb = Workbook()
    
    # Sheet 1: Execution Tracker Counts
    ws1 = wb.active
    ws1.title = "Execution Tracker Counts"
    for r in dataframe_to_rows(counts_df, index=False, header=True):
        ws1.append(r)

    # Sheet 2: Evidence Counts
    ws_evidence = wb.create_sheet("Evidence Counts")
    ws_evidence.append(["Table", "Row Count"])
    ws_evidence.append(["Account", len(account_df)])
    ws_evidence.append(["Account_final", len(account_final_df)])

    # Sheet 3: Mismatch Summary
    ws2 = wb.create_sheet("Mismatch Summary")
    for r in dataframe_to_rows(mismatches_df, index=False, header=True):
        ws2.append(r)

    # Sheet 4: Detailed Comparison
    ws3 = wb.create_sheet("Detailed Comparison")
    for r in dataframe_to_rows(merged_df, index=False, header=True):
        ws3.append(r)

    # Highlight mismatches
    red_fill = PatternFill(start_color="FF9999", end_color="FF9999", fill_type="solid")
    for _, row in mismatches_df.iterrows():
        row_idx = merged_df.index[merged_df['id'] == row['id']][0] + 2
        src_idx = list(merged_df.columns).index(row['source_column']) + 1
        tgt_idx = list(merged_df.columns).index(row['target_column']) + 1
        ws3.cell(row=row_idx, column=src_idx).fill = red_fill
        ws3.cell(row=row_idx, column=tgt_idx).fill = red_fill

    wb.save("account_validation_report.xlsx")

# Main
conn = connect_snowflake()
cursor = conn.cursor()
account_df = fetch_table(cursor, "Account")
account_final_df = fetch_table(cursor, "Account_final")
execution_tracker_df = fetch_table(cursor, "execution_tracker")

execution_tracker_df.columns = [c.lower() for c in execution_tracker_df.columns]
account_tracker = execution_tracker_df[execution_tracker_df['report'].str.lower() == 'account']

mismatches_df, merged_df = compare_by_primary_key(account_df, account_final_df, column_mappings)

counts_summary = account_tracker[['type', 'status', 'report']].copy()
counts_summary['rows_in_account'] = len(account_df)
counts_summary['rows_in_account_final'] = len(account_final_df)

generate_excel(counts_summary, mismatches_df, merged_df, account_df, account_final_df)

cursor.close()
conn.close()