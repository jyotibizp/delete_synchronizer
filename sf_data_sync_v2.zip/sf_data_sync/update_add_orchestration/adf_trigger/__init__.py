import logging
import requests
import azure.functions as func
from azure.identity import ClientSecretCredential

def main(name: str) -> str:

    tenant_id = "cca76bf2-ad28-4adb-bbd0-deeb9dd15a80"
    client_id = "9498f0d5-005a-484f-99b7-6e0af0da097f"
    client_secret = "cer8Q~lvEJ73vu_btutM~vSqOwILzLANWoXa3diY"
    # ADF details
    subscription_id = "086b4500-6281-444b-8430-40696735e453"
    resource_group = "PrivateWealth"
    factory_name = "bocdevdf"
    pipeline_name = name

    # Authenticate
    credential = ClientSecretCredential(tenant_id, client_id, client_secret)
    token = credential.get_token("https://management.azure.com/.default").token

    # Construct ADF pipeline trigger URL
    url = f"https://management.azure.com/subscriptions/{subscription_id}/resourceGroups/{resource_group}/providers/Microsoft.DataFactory/factories/{factory_name}/pipelines/{pipeline_name}/createRun?api-version=2018-06-01"

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    # Optional: pass parameters
    payload = {
        "parameters": {
            "Pipeline_object": pipeline_name,
            "Pipeline_dataFactory": "IC_pipeline"
        }
    }

    response = requests.post(url,  headers=headers, json=payload)
    run_id = response.json().get("runId")
    return run_id
   