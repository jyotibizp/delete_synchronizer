import logging
import requests
import azure.functions as func
from azure.identity import ClientSecretCredential

def main(input_data: dict) -> str:
    runid = input_data["runid"]
    #token = input_data["token"]
    
    tenant_id = "cca76bf2-ad28-4adb-bbd0-deeb9dd15a80"
    client_id = "9498f0d5-005a-484f-99b7-6e0af0da097f"
    client_secret = "cer8Q~lvEJ73vu_btutM~vSqOwILzLANWoXa3diY"

    credential = ClientSecretCredential(tenant_id, client_id, client_secret)
    token = credential.get_token("https://management.azure.com/.default").token

    subscriptionid = "086b4500-6281-444b-8430-40696735e453"
    resourcegroup = "PrivateWealth"
    factoryname = "bocdevdf"

    url_runid = f"https://management.azure.com/subscriptions/{subscriptionid}/resourceGroups/{resourcegroup}/providers/Microsoft.DataFactory/factories/{factoryname}/pipelineruns/{runid}?api-version=2018-06-01"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    response = requests.get(url_runid, headers=headers)
    status = response.json().get("status")
    return status
   