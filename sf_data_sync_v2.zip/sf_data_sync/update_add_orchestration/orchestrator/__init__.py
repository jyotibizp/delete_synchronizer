import azure.durable_functions as df

def orchestrator_function(context: df.DurableOrchestrationContext):
    input_data = context.get_input()
    list_tasks = input_data['list_tasks']
    result = {}
    for i in list_tasks:
        results = yield context.call_activity("adf_trigger", i)
        result[i] = results

    # check run ids status
    # stat_runid = {}
    # for i in result.keys():
    #     stat_runid[i] = "InProgress"
    # while "InProgress" in stat_runid.values():
    #     yield context.create_timer(context.current_utc_datetime + timedelta(seconds=30))
    #     for i in stat_runid.keys():
    #         status = yield context.call_activity("check_run_status", result[i])
    #         stat_runid[i] = status
    #     for i in result.keys():
    #         if stat_runid[i] != "InProgress":
    #           del stat_runid[i]
    #     
    return "done"

main = df.Orchestrator.create(orchestrator_function)
