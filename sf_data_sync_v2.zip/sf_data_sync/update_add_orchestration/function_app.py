import azure.functions as func
import datetime
import json
import logging

app = func.FunctionApp()