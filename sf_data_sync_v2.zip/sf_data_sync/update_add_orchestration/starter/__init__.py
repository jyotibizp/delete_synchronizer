import azure.functions as func
import azure.durable_functions as df
import json
import asyncio
import logging

async def main(mytimer: func.TimerRequest, starter: str) -> None:
    client = df.DurableOrchestrationClient(starter)
    input_data = {'list_tasks':['Account', 'Activity_Content', 'Contact', 'Event', 'Fund',
                  'Investment', 'Legal_Entity', 'LP_Consultant_Relationship', 'Opportunity', 'Task']}
    instance_id = await client.start_new("orchestrator", None, input_data)
    logging.info(f"Started orchestration with ID = '{instance_id}'")
