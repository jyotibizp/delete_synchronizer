import snowflake.connector
import pandas as pd
from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import PatternFill

# Connect to Snowflake
def connect_snowflake():
    return snowflake.connector.connect(
        account="NP91221-IC_IBD_CRM",
        user="rajani.gutha@blueowl.com",
        authenticator='externalbrowser',
        role="IC_CRM_DEVELOPER",
        warehouse='"IC_CRM_WH_XS"',
        database='IC_CRM_DB',
        schema='IC_CRM'
    )

# Fetch column mappings dynamically
def fetch_column_mappings(cursor, table1, table2):
    cursor.execute(f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table1}'")
    cols1 = [row[0].lower() for row in cursor.fetchall()]
    cursor.execute(f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table2}'")
    cols2 = [row[0].lower() for row in cursor.fetchall()]
    # Map columns that exist in both tables
    return {col: col for col in cols1 if col in cols2}

# Fetch table data
def fetch_table(cursor, table_name):
    cursor.execute(f"SELECT * FROM {table_name}")
    cols = [c[0].lower() for c in cursor.description]
    rows = cursor.fetchall()
    return pd.DataFrame(rows, columns=cols)

# Compare tables using primary key 'id'
def compare_by_primary_key(df1, df2, mappings):
    merged = df1.merge(df2, on='id', suffixes=('_account', '_history'))
    mismatches = []
    for idx, row in merged.iterrows():
        for col in mappings.keys():
            col1 = f"{col}_account"
            col2 = f"{col}_history"
            if col1 in merged.columns and col2 in merged.columns:
                val1 = row[col1]
                val2 = row[col2]
                if pd.isnull(val1) and pd.isnull(val2):
                    continue
                if val1 != val2:
                    mismatches.append({
                        "id": row['id'],
                        "column": col,
                        "account_value": val1,
                        "history_value": val2
                    })
    return pd.DataFrame(mismatches), merged

# Generate Excel report
def generate_excel(mismatches_df, merged_df):
    wb = Workbook()

    # Sheet 1: Mismatch Summary
    ws1 = wb.active
    ws1.title = "Mismatch Summary"
    for r in dataframe_to_rows(mismatches_df, index=False, header=True):
        ws1.append(r)

    # Sheet 2: Detailed Comparison
    ws2 = wb.create_sheet("Detailed Comparison")
    for r in dataframe_to_rows(merged_df, index=False, header=True):
        ws2.append(r)

    # Highlight mismatches
    red_fill = PatternFill(start_color="FF9999", end_color="FF9999", fill_type="solid")
    for _, row in mismatches_df.iterrows():
        row_idx = merged_df.index[merged_df['id'] == row['id']][0] + 2
        col_account = f"{row['column']}_account"
        col_history = f"{row['column']}_history"
        if col_account in merged_df.columns and col_history in merged_df.columns:
            col_idx1 = list(merged_df.columns).index(col_account) + 1
            col_idx2 = list(merged_df.columns).index(col_history) + 1
            ws2.cell(row=row_idx, column=col_idx1).fill = red_fill
            ws2.cell(row=row_idx, column=col_idx2).fill = red_fill

    wb.save("account_vs_history_comparison.xlsx")

# Main execution
conn = connect_snowflake()
cursor = conn.cursor()

# Fetch column mappings dynamically
column_mappings = fetch_column_mappings(cursor, "ACCOUNT", "HISTORY_ACCOUNT")

# Fetch data
account_df = fetch_table(cursor, "ACCOUNT")
history_df = fetch_table(cursor, "HISTORY_ACCOUNT")

# Compare and generate report
mismatches_df, merged_df = compare_by_primary_key(account_df, history_df, column_mappings)
generate_excel(mismatches_df, merged_df)

cursor.close()
conn.close()