"""Schemas for event data structures."""

