import snowflake.connector
import json
from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.worksheet.table import Table, TableStyleInfo

def connect_snowflake():
    return snowflake.connector.connect(
        account="NP91221-IC_IBD_CRM",
        user="rajani.gutha@blueowl.com",
        authenticator='externalbrowser',
        role="IC_CRM_DEVELOPER",
        warehouse='"IC_CRM_WH_XS"',
        database='IC_CRM_DB',
        schema='IC_CRM'
    )

conn = connect_snowflake()
cursor = conn.cursor()

cursor.execute("""
    SELECT TYPE, STATUS, REPORT, INSERTED_DATE
    FROM EXECUTION_TRACKER
    WHERE TYPE LIKE '%Activity_Content%' OR TYPE LIKE '%ActivityContent%'
    ORDER BY INSERTED_DATE DESC
    LIMIT 1
""")
row = cursor.fetchone()

if row is None:
    print("❌ No matching row found for Activity_Content or ActivityContent in EXECUTION_TRACKER.")
else:
    type_value, status, report_json, inserted_date = row
    # Parse REPORT JSON safely
    if report_json and report_json.strip():
        report_data = json.loads(report_json)
    else:
        report_data = {}

    expected_count = report_data.get("Total_rows_copied", 0)
    updated_count = report_data.get("Total_rows_updated", 0)
    inserted_count = report_data.get("Total_rows_inserted", 0)

    # Normalize table name
    table_name = type_value.split('/')[-1].replace('_', '')

    # Query actual row count from normalized table name
    cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
    actual_count = cursor.fetchone()[0]

    pass_fail = "Pass" if actual_count == expected_count else "Fail"

    result_data = [{
        "Table Name": table_name,
        "Expected Count": expected_count,
        "Actual Count": actual_count,
        "Pass/Fail": pass_fail,
        "Status": status,
        "Inserted Date": inserted_date,
        "Updated Count": updated_count,
        "Inserted Count": inserted_count
    }]

    wb = Workbook()
    ws = wb.active
    ws.title = "Execution Tracker Results"

    headers = list(result_data[0].keys())
    ws.append(headers)

    for result in result_data:
        ws.append(list(result.values()))

    for cell in ws[1]:
        cell.font = Font(bold=True)

    table = Table(displayName="ExecutionResults", ref=f"A1:H2")
    style = TableStyleInfo(name="TableStyleMedium9", showFirstColumn=False,
                           showLastColumn=False, showRowStripes=True, showColumnStripes=False)
    table.tableStyleInfo = style
    ws.add_table(table)

    for col in ws.columns:
        max_length = max(len(str(cell.value)) for cell in col)
        ws.column_dimensions[col[0].column_letter].width = max_length + 2

    wb.save("execution_tracker_results.xlsx")
    print("✅ Excel file 'execution_tracker_results.xlsx' created successfully.")

cursor.close()
conn.close()