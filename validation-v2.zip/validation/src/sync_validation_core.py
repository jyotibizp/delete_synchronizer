import json
import logging
import pandas as pd
from datetime import datetime
from salesforce import connect_salesforce
from snowflake import connect_snowflake
from data_dict import SF_OBJECT_TO_SNOWFLAKE_TABLE

def get_salesforce_count(sf, sf_object):
    try:
        result = sf.query(f"SELECT COUNT(Id) FROM {sf_object}")
        return result['records'][0].get('expr0', 0)
    except Exception as e:
        logging.error(f"Error querying Salesforce {sf_object}: {e}")
        return -1

def get_snowflake_count(cursor, table_name):
    try:
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        return cursor.fetchone()[0]
    except Exception as e:
        logging.error(f"Error querying Snowflake {table_name}: {e}")
        return -1

def get_delete_tracker_stats(cursor):
    cursor.execute("""
        SELECT OBJECT_NAME, STATUS, COUNT(*) as COUNT
        FROM DELETE_TRACKER
        GROUP BY OBJECT_NAME, STATUS
        ORDER BY OBJECT_NAME, STATUS
    """)
    results = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    return pd.DataFrame(results, columns=columns)

def get_delete_tracker_count(cursor, object_name):
    try:
        cursor.execute(f"SELECT COUNT(*) FROM DELETE_TRACKER WHERE OBJECT_NAME = '{object_name}' AND STATUS = 'open'")
        return cursor.fetchone()[0]
    except Exception as e:
        logging.error(f"Error querying DELETE_TRACKER for {object_name}: {e}")
        return 0

def get_history_counts(cursor, base_table):
    try:
        cursor.execute(f"SELECT COUNT(*) FROM HISTORY_{base_table}")
        history_count = cursor.fetchone()[0]
        cursor.execute(f"SELECT COUNT(*) FROM HISTORY_{base_table} WHERE STATUS = 'DELETED'")
        deleted_count = cursor.fetchone()[0]
        return history_count, deleted_count
    except Exception as e:
        logging.warning(f"Error getting history counts for {base_table}: {e}")
        return 0, 0

def run_sync_validation():
    sf = connect_salesforce()
    conn = connect_snowflake()
    cursor = conn.cursor()
    logging.info("Starting sync validation...")

    delete_stats_df = get_delete_tracker_stats(cursor)
    validation_results = []

    for mapping in SF_OBJECT_TO_SNOWFLAKE_TABLE:
        sf_object = mapping['sf_object']
        sf_table = mapping['snowflake_table']
        sf_final_table = mapping['snowflake_final_table']

        sf_count = get_salesforce_count(sf, sf_object)
        snowflake_base_count = get_snowflake_count(cursor, sf_table)
        snowflake_final_count = get_snowflake_count(cursor, sf_final_table)
        pending_deletes = get_delete_tracker_count(cursor, sf_object)
        history_total, history_deleted = get_history_counts(cursor, sf_table)

        base_match = (sf_count == snowflake_base_count)
        final_match = (sf_count == snowflake_final_count)

        validation_results.append({
            'object': sf_object,
            'salesforce_count': sf_count,
            'snowflake_base_count': snowflake_base_count,
            'snowflake_final_count': snowflake_final_count,
            'base_match': base_match,
            'final_match': final_match,
            'base_diff': snowflake_base_count - sf_count if sf_count >= 0 and snowflake_base_count >= 0 else None,
            'final_diff': snowflake_final_count - sf_count if sf_count >= 0 and snowflake_final_count >= 0 else None,
            'pending_deletes': pending_deletes,
            'history_total': history_total,
            'history_deleted': history_deleted
        })

    # Summary
    total_objects = len(validation_results)
    base_matches = sum(1 for r in validation_results if r['base_match'])
    final_matches = sum(1 for r in validation_results if r['final_match'])
    all_match = base_matches == total_objects and final_matches == total_objects
    total_pending = sum(r['pending_deletes'] for r in validation_results)
    total_deleted = sum(r['history_deleted'] for r in validation_results)

    if all_match and total_pending == 0:
        status = "SUCCESS"
        log_message = f"All {total_objects} objects validated. Counts match. {total_deleted} records in history."
    elif all_match and total_pending > 0:
        status = "PENDING"
        log_message = f"Counts match but {total_pending} deletes pending across {total_objects} objects."
    else:
        mismatches = sum(1 for r in validation_results if not r['base_match'] or not r['final_match'])
        status = "WARNING"
        log_message = f"{mismatches} objects with count mismatches. {total_pending} deletes pending."

    report_data = {
        'validation_type': 'SYNC_VALIDATION',
        'timestamp': datetime.now().isoformat(),
        'summary': {
            'status': status,
            'total_objects': total_objects,
            'base_matches': base_matches,
            'final_matches': final_matches,
            'all_counts_match': all_match,
            'total_pending_deletes': total_pending,
            'total_deleted_in_history': total_deleted,
            'log_message': log_message
        },
        'delete_tracker_summary': delete_stats_df.to_dict(orient='records') if not delete_stats_df.empty else [],
        'validation_results': validation_results
    }

    try:
        cursor.execute("""
            INSERT INTO EXECUTION_TRACKER (TYPE, STATUS, LOG_MESSAGE, REPORT)
            VALUES (%s, %s, %s, %s)
        """, ('SYNC_VALIDATION', status, log_message, json.dumps(report_data)))
        conn.commit()
        logging.info(f"Results saved to EXECUTION_TRACKER (Status: {status})")
    except Exception as e:
        logging.error(f"Failed to save to EXECUTION_TRACKER: {e}")

    cursor.close()
    conn.close()
    logging.info(f"Validation completed: {status}")
    return report_data