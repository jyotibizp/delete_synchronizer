
#config.py

class settings:
    SF_PRIVATE_KEY_FILE = "C:/Users/rgutha/Documents/salesforce_keys/server.key"
    SF_CLIENT_ID = "3MVG9JEx.BE6yifNk5USP3ASdT_LZ4L6eB_b0FonxbMtt87E8Otty_Au9XXVlYYvrjKAU7CJuO0aLkaCwD7N1"
    SF_USERNAME = "pradeep.verma@blueowl.com"
    SF_LOGIN_URL = "https://login.salesforce.com"

    OUTPUT_JSON_FILE = "salesforce_output.json"
    SNOWFLAKE_OUTPUT_JSON_FILE = "snowflake_output.json"


